#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rs01_to_oscar.py - converts Contec RS01 recordings (.HD + .SEG files from the TF card)
into files OSCAR can import.

RS01 format (decoded from the device's files):
  .HD   512-byte ASCII header: start time (YYYYMMDDHHMMSS at offset 0x16),
        record length, signals (Flow 50 Hz, PR 1 Hz, SpO2 1 Hz, Pleth 100 Hz).
  .SEG  512-byte header, then one 206-byte record per second:
          FF FF | record number (uint16 LE) | Flow 50 x uint16 LE | PR | SpO2 | Pleth 100 x uint8
        PR = 0 / SpO2 = 0 means no valid reading (finger out).

Output, for each recording:
  YYYYMMDDHHMMSS         Viatom/Wellue (O2Ring) file: OSCAR > File > Import > Viatom/Wellue data
  YYYYMMDDHHMMSS.csv     second-by-second SpO2 and pulse, for a spreadsheet
OSCAR has no channel for the nasal airflow or the pleth wave from this format; they are not exported.

Examples:
  python3 rs01_to_oscar.py /Volumes/RS01                  whole card (searches subfolders)
  python3 rs01_to_oscar.py ~/Desktop/nuit -o ~/Desktop/oscar
  python3 rs01_to_oscar.py /Volumes/RS01 --interval 4     4 s resolution, like an O2Ring
"""

import argparse
import csv
import struct
import sys
from datetime import datetime, timedelta
from pathlib import Path

RECORD_SIZE = 206
SEG_HEADER = 512
VIATOM_HEADER = 40


def field(hd, offset, width):
    return hd[offset:offset + width].decode("ascii", "replace").strip()


def read_hd(path):
    hd = path.read_bytes()
    if len(hd) < 0x16A:
        raise ValueError("HD file too short")
    start = datetime.strptime(field(hd, 0x16, 14), "%Y%m%d%H%M%S")
    per_seg = int(field(hd, 0x78, 4) or 600)
    nsig = int(field(hd, 0x88, 2))
    labels = [field(hd, 0x8A + 8 * i, 8) for i in range(nsig)]
    base = 0x8A + 8 * nsig
    rates = [int(field(hd, base + 4 * i, 4)) for i in range(nsig)]
    sizes = [int(field(hd, base + 4 * nsig + 4 * i, 4)) for i in range(nsig)]
    if labels != ["Flow", "PR", "SpO2", "Pleth"] or rates != [50, 1, 1, 100] or sizes != [2, 1, 1, 1]:
        raise ValueError(f"unexpected signal layout {labels} {rates} {sizes}")
    return start, per_seg


def read_segments(folder, per_seg):
    """Returns {second_index (0-based): (spo2, pr)}."""
    samples = {}
    segs = sorted((p for p in folder.iterdir() if p.suffix.upper() == ".SEG"),
                  key=lambda p: int(p.stem) if p.stem.isdigit() else 0)
    for seg in segs:
        n = int(seg.stem) if seg.stem.isdigit() else 1
        body = seg.read_bytes()[SEG_HEADER:]
        count = len(body) // RECORD_SIZE
        if not count:
            continue
        first = struct.unpack_from("<H", body, 2)[0]
        # Record numbers may restart in each segment or run on; handle both.
        offset = 0 if first > (n - 1) * per_seg else (n - 1) * per_seg
        for i in range(count):
            r = body[i * RECORD_SIZE:(i + 1) * RECORD_SIZE]
            if r[:2] != b"\xff\xff":
                print(f"  {seg.name}: record {i} misaligned, rest of the file skipped")
                break
            idx = struct.unpack_from("<H", r, 2)[0] + offset - 1
            samples[idx] = (r[105], r[104])
    return samples, len(segs)


def valid(s):
    spo2, pr = s
    return 50 <= spo2 <= 100 and 20 <= pr <= 250


def write_viatom(path, start, recs, interval):
    data = bytearray()
    for spo2, pr in recs:
        if spo2 is None:
            data += bytes([0xFF, 0xFF, 1, 0, 0])
        else:
            data += bytes([spo2, pr, 0, 0, 0])
    size = VIATOM_HEADER + len(data)
    header = struct.pack("<HHBBBBBIH", 0x0003, start.year, start.month, start.day,
                         start.hour, start.minute, start.second, size, len(recs) * interval)
    path.write_bytes(header.ljust(VIATOM_HEADER, b"\0") + data)


def convert(hd_path, outdir, interval):
    folder = hd_path.parent
    print(f"{hd_path}:")
    start, per_seg = read_hd(hd_path)
    samples, nseg = read_segments(folder, per_seg)
    if not samples:
        print("  no .SEG data next to this file, skipped")
        return
    good = [i for i, s in samples.items() if valid(s)]
    if not good:
        print(f"  start {start:%Y-%m-%d %H:%M:%S}, {len(samples)} s recorded, no valid SpO2 reading, skipped")
        return
    first, last = min(good), max(good)
    first -= first % interval
    t0 = start + timedelta(seconds=first)
    name = f"{t0:%Y%m%d%H%M%S}"

    with open(outdir / f"{name}.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["time", "spo2", "pulse"])
        for i in range(first, last + 1):
            s = samples.get(i)
            ok = s is not None and valid(s)
            w.writerow([f"{start + timedelta(seconds=i):%Y-%m-%d %H:%M:%S}",
                        s[0] if ok else "", s[1] if ok else ""])

    recs = []
    for w0 in range(first, last + 1, interval):
        win = [samples[i] for i in range(w0, w0 + interval) if i in samples and valid(samples[i])]
        if win:
            recs.append((round(sum(s[0] for s in win) / len(win)),
                         round(sum(s[1] for s in win) / len(win))))
        else:
            recs.append((None, None))
    write_viatom(outdir / name, t0, recs, interval)

    spo2s = [samples[i][0] for i in good]
    print(f"  {nseg} segment(s), recording start {start:%Y-%m-%d %H:%M:%S}, "
          f"{len(samples)} s recorded, {len(good)} s valid")
    print(f"  valid data from {t0:%H:%M:%S} to {start + timedelta(seconds=last):%H:%M:%S}, "
          f"SpO2 min {min(spo2s)} %, mean {sum(spo2s) / len(spo2s):.1f} %")
    print(f"  -> {outdir / name}  (+ .csv)")


def main():
    ap = argparse.ArgumentParser(description="Contec RS01 -> OSCAR (Viatom format) + CSV.")
    ap.add_argument("paths", nargs="+", help="folders (searched recursively) or .HD files")
    ap.add_argument("-o", "--outdir", default="rs01_oscar", help="output folder (default: rs01_oscar)")
    ap.add_argument("--interval", type=int, choices=(1, 2, 4), default=1,
                    help="seconds per sample in the OSCAR file (default 1; 4 = O2Ring rhythm)")
    args = ap.parse_args()

    hds = []
    for p in map(Path, args.paths):
        p = p.expanduser()
        if p.is_dir():
            hds += [h for h in p.rglob("*") if h.suffix.upper() == ".HD" and not h.name.startswith("._")]
        elif p.suffix.upper() == ".HD":
            hds.append(p)
    if not hds:
        sys.exit("No .HD file found.")

    by_folder = {}
    for h in hds:
        by_folder.setdefault(h.parent, []).append(h)
    outdir = Path(args.outdir).expanduser()
    outdir.mkdir(parents=True, exist_ok=True)

    for folder, files in sorted(by_folder.items()):
        if len(files) > 1:
            print(f"{folder}: several .HD files in one folder ({', '.join(f.name for f in files)}); "
                  "put each recording (.HD + its .SEG files) in its own folder. Skipped.")
            continue
        try:
            convert(files[0], outdir, args.interval)
        except (ValueError, OSError) as e:
            print(f"{files[0]}: {e}")


if __name__ == "__main__":
    main()
