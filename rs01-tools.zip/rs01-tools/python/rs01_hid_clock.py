#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rs01_hid_clock.py - sets the clock of a Contec RS01 over USB HID (VID 28E9, PID 01F3).

Protocol taken from ResMon Plus 3.0.2.2 (function that logs "time setting complete"):
  64-byte output report, no report ID:
    83 YY MM DD hh mm ss 00 00 CS   then zeros up to 64 bytes
    YY = year - 2000, CS = (sum of the 9 preceding bytes) & 0x7F
  Expected reply: F3 00 73 ...
ResMon Plus also sends 81 01 (query) before and 84 01 (mode switch) after;
this script sends ONLY the clock command.

Requirement: pip install hidapi
Examples:
  python3 rs01_hid_clock.py                dry run: shows the packet, sends nothing
  python3 rs01_hid_clock.py --send         sets the clock
  python3 rs01_hid_clock.py --send --offset 120   test: sets the clock 2 minutes ahead
"""

import argparse
import sys
import time
from datetime import datetime, timedelta

VID, PID = 0x28E9, 0x01F3
REPORT_SIZE = 64


def clock_packet(t):
    body = [0x83, (t.year - 2000) & 0x7F, t.month & 0x0F, t.day & 0x1F,
            t.hour & 0x1F, t.minute & 0x3F, t.second & 0x3F, 0x00, 0x00]
    return bytes(body + [sum(body) & 0x7F])


def hexs(b):
    return " ".join(f"{x:02x}" for x in b)


def wait_for_whole_second():
    target = datetime.now().replace(microsecond=0) + timedelta(seconds=1)
    time.sleep(max(0.0, (target - datetime.now()).total_seconds()))
    return target


def main():
    ap = argparse.ArgumentParser(description="Contec RS01 clock over USB HID.")
    ap.add_argument("--send", action="store_true", help="actually send (otherwise dry run)")
    ap.add_argument("--offset", type=float, default=0.0, help="seconds to add to the time sent")
    args = ap.parse_args()

    if not args.send:
        t = datetime.now().replace(microsecond=0) + timedelta(seconds=args.offset)
        print("DRY RUN, nothing is sent.")
        print(f"  packet: {hexs(clock_packet(t))} + zeros up to 64 bytes  (time {t:%Y-%m-%d %H:%M:%S})")
        print("Add --send to actually send it.")
        return

    try:
        import hid
    except ImportError:
        sys.exit("hidapi module missing: run  pip install hidapi")

    if not hid.enumerate(VID, PID):
        sys.exit("RS01 not found (USB 28E9:01F3). Switch it on, plug it in, then try again.")

    h = hid.device()
    try:
        h.open(VID, PID)
    except OSError as e:
        sys.exit(f"Could not open the device: {e}")

    try:
        h.set_nonblocking(True)
        while h.read(REPORT_SIZE):             # discard anything already waiting
            pass
        h.set_nonblocking(False)

        t = wait_for_whole_second() + timedelta(seconds=args.offset)
        pkt = clock_packet(t)
        report = [0x00] + list(pkt) + [0x00] * (REPORT_SIZE - len(pkt))
        n = h.write(report)
        print(f"Sent: {hexs(pkt)} (time {t:%Y-%m-%d %H:%M:%S}, write result {n})")

        reply = h.read(REPORT_SIZE, 2000)
    finally:
        h.close()

    if not reply:
        print("No reply. Check the time on the RS01 screen; do not keep retrying.")
    elif reply[:3] == [0xF3, 0x00, 0x73]:
        print("Reply F3 00 73: clock set. Check the RS01 screen.")
    else:
        print(f"Unexpected reply: {hexs(reply[:8])} ... Check the RS01 screen; do not keep retrying.")


if __name__ == "__main__":
    main()
